import javafx.application.*;
import javafx.event.*;
import javafx.scene.*;
import javafx.scene.image.*;
import javafx.scene.control.*;
import javafx.scene.control.Alert.*;
import javafx.scene.text.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.paint.Color.*;
import javafx.scene.shape.*;
import javafx.stage.*;
import javafx.geometry.*;
import javafx.animation.*;
import java.io.*;
import java.util.*;
import javafx.event.EventHandler;
import javafx.scene.input.KeyEvent;

public class MovableBG extends Application {

   private Stage stage;
   private Scene scene;
   private StackPane root;

   private static String[] args;
   private final static String CREWMATE_IMAGE = "amogus-02.png";
   private final static String CREWMATE_RUNNERS = "amogus-03.png";
   private final static String BACKGROUND_IMAGE = "amogus-01.png";

   CrewmateRacer crewmateRacer = null;
   ArrayList<CrewmateRacer> crewmateRunners = new ArrayList<>();

   MovableBackground movableBackground = null;

   AnimationTimer aniTimer = null;
   private long renderCounter = 0;
   boolean goUP = false, goDOWN = false, goLEFT = false, goRIGHT = false;

   Image backgroundCollision = null;

   public static void main(String[] _args) {
      args = _args;
      launch(args);
   }

   public void start(Stage _stage) {
      stage = _stage;
      stage.setTitle("MovableBG");
      stage.setOnCloseRequest(
                new EventHandler<WindowEvent>() {
                   public void handle(WindowEvent evt) {
                      System.exit(0);
                   }
                });
      root = new StackPane();
      initializeScene();
   
   }

   public void initializeScene() {
   
      crewmateRacer = new CrewmateRacer(true);
      for (int i = 0; i < 5; i++) {
         CrewmateRacer cR = new CrewmateRacer(false);
         crewmateRunners.add(cR);
      }
      movableBackground = new MovableBackground();
   
      root.getChildren().add(movableBackground);
      root.getChildren().add(crewmateRacer);
      for (int i = 0; i < crewmateRunners.size(); i++) {
         System.out.println("");
      }
   
      scene = new Scene(root, 1280, 720);
      stage.setScene(scene);
      stage.show();
   
      scene.setOnKeyPressed(
                new EventHandler<KeyEvent>() {
                   @Override
                   public void handle(KeyEvent event) {
                      switch (event.getCode()) {
                         case UP:
                            goUP = true;
                            break;
                         case DOWN:
                            goDOWN = true;
                            break;
                         case RIGHT:
                            goRIGHT = true;
                            break;
                         case LEFT:
                            goLEFT = true;
                            break;
                      }
                   }
                });
   
      scene.setOnKeyReleased(
                new EventHandler<KeyEvent>() {
                   @Override
                   public void handle(KeyEvent event) {
                      switch (event.getCode()) {
                         case UP:
                            goUP = false;
                            break;
                         case DOWN:
                            goDOWN = false;
                            break;
                         case RIGHT:
                            goRIGHT = false;
                            break;
                         case LEFT:
                            goLEFT = false;
                            break;
                      }
                   }
                });
   
      backgroundCollision = new Image(BACKGROUND_IMAGE);
   
      aniTimer = 
         new AnimationTimer() {
            @Override
            public void handle(long now) {
               crewmateRacer.update();
            
               for (int i = 0; i < crewmateRunners.size(); i++) {
                  crewmateRunners.get(i).update();
               }
               movableBackground.update();
            }
         };
   
      aniTimer.start();
   
   }

   class CrewmateRacer extends Pane {
      private int racePosX = 0;
      private int racePosY = 0;
      private ImageView aPicView = null;
      private boolean isMaster = true;
   
      public CrewmateRacer(boolean isMaster) {
         this.isMaster = isMaster;
         if (isMaster) {
            aPicView = new ImageView(CREWMATE_IMAGE);
            racePosX = 550;
            racePosY = 250;
         } else {
            aPicView = new ImageView(CREWMATE_RUNNERS);
         }
         this.getChildren().add(aPicView);
      }
   
      public void update() {
         double speed = 2;
         if (isMaster) {
            Color color = backgroundCollision.getPixelReader().getColor(racePosX, racePosY);
         
            if (color.getRed() > 0) {
               speed = 2;
            }
         
            int targetX = 0;
            int targetY = 0;
            double dist = Math.sqrt(Math.pow(racePosX - targetX, 2) + Math.pow(racePosY - targetY, 2));
         
            if (goDOWN == true)
               racePosY += speed;
            if (goUP == true)
               racePosY -= speed;
            if (goLEFT == true)
               racePosX -= speed;
            if (goRIGHT == true)
               racePosX += speed;
         } else {
            racePosX += Math.random() * speed;
            racePosY += Math.random() * speed;
         }
      
         aPicView.setTranslateX(racePosX);
         aPicView.setTranslateY(racePosY);
      
         if (racePosX < 0)
            racePosX = 0;
         if (racePosY < 0)
            racePosY = 0;
      }
   
   }

   class MovableBackground extends Pane {
      private int racePosX = -50;
      private int racePosY = -400;
      private ImageView aPicView = null;
   
      public MovableBackground() {
         aPicView = new ImageView(BACKGROUND_IMAGE);
         this.getChildren().addAll(aPicView);
      }
   
      public void update() {
         double speed = 5;
         if (goDOWN == true)
            racePosY -= speed;
         if (goUP == true)
            racePosY += speed;
         if (goLEFT == true)
            racePosX += speed;
         if (goRIGHT == true)
            racePosX -= speed;
      
         aPicView.setTranslateX(racePosX);
         aPicView.setTranslateY(racePosY);
      
      }
   }

}
